Optimum OSD version 10 readme, this OSD was made by verttexz (discord) and is a free use OSD
anyone else other than verttexz (like verttexzofficial vertexz verttexzreal optimum.crew) claiming that they own optimum
or saying that Optimum is a paid OSD which it isn't. Do not buy from them they are selling malware to you.
---------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
How to use Optimum OSD

Step 1.) Open the RTSS Overlays Folder (C:\Program Files (x86)\RivaTuner Statistics Server\Plugins\Client\Overlays or
C:\Program Files\RivaTuner Statistics Server\Plugins\Client\Overlays)

Step 2.) Take the Optimum OSD Overlays Folder and replace it with the RTSS Overlays Folder

Step 3.) Open RTSS and click setup, then click plugins, double click on OverlayEditor.dll and on your keyboard
press CTRL + O and either click OptimumOSDv10(FPSGraph).ovl or OptimumOSDv10.ovl


Video Explanation: not out yet